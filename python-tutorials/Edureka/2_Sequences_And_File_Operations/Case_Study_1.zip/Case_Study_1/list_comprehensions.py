mystr = "HtErlxl*o"
my_list = []

for ch in mystr:
    my_list.append(ch)
print(my_list)
