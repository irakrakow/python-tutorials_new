d = {"john": 40, "peter": 45}  # d is a dictionary
print(list(d.keys()))
print(list(d.values()))
# ['john, 'peter']  Prints the keys of the dictionary as a list
# [40,45] prints the values in the dictionary as a list
