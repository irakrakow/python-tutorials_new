aString = input("String to reverse: ")

print(f"Original string: {aString} ")
print(f"Reversed string (extended slice notation): {aString[::-1]} ")
