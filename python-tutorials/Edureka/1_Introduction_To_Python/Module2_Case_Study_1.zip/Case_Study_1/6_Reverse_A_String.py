# Get the input string from the user
string = input("Enter a string: ")

# Reverse the string. Use negative step to do the reversal
reversed_string = string[::-1]

# Print the reversed string
print(reversed_string)
