
string = "H1e2l3l4o5w6o7r8l9d"

for i, char in enumerate(string):
    if i % 2 == 0:
        print(char, end="")
