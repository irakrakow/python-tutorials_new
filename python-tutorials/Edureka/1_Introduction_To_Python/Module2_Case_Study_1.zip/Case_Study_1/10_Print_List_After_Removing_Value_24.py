my_list = [12,24,35,70,88,120,155]
new_list = [x for x in my_list if x != 24]
print(new_list) #[12, 35, 70, 88, 120, 155]
